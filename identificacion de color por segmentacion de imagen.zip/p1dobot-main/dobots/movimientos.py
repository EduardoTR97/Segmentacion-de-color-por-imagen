import threading
import DobotDllType as dType
import mqtt
api = dType.load()

def movimientos(datos,broker, port):
    st=True
    longlista= len(datos)
    for i in range (longlista):
        color=datos[i][0]
        if color == "Rojo":
            topic = "Rojo"
            message = 1
            mqtt.enviar_mensaje_mqtt(broker, port, topic, message)
            Axis_x=datos[i][1]+185
            Axis_y=108-datos[i][2]# -3 del home en y, 30 de dimension y y esta en la posicion 1
            gripper_angle=datos[i][3]
            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, Axis_x , Axis_y, 10, -gripper_angle, isQueued = 1)[0]
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetQueuedCmdStopExec(api)
            dType.SetEndEffectorGripperEx(api, st,not st)
            dType.dSleep(500)

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, Axis_x , Axis_y, -4, -gripper_angle, isQueued = 1)[0]
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetEndEffectorGripperEx(api,st,not st)
            dType.SetQueuedCmdStopExec(api)
            dType.dSleep(500)

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, Axis_x , Axis_y, -20, -gripper_angle, isQueued = 1)[0]
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetEndEffectorGripperEx(api,st,st)
            dType.SetQueuedCmdStopExec(api)
            dType.dSleep(500)

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, Axis_x , Axis_y, 60, -gripper_angle, isQueued = 1)[0]
            dType.SetQueuedCmdStartExec(api)

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, 245 , 46, 70, -gripper_angle, isQueued = 1)[0]
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetQueuedCmdStopExec(api)
            dType.SetEndEffectorGripperEx(api,st, st)
            dType.dSleep(500)

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, 46 , 198.89, 70, gripper_angle, isQueued = 1)[0] 
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetEndEffectorGripperEx(api,st,not st)
            dType.SetQueuedCmdStopExec(api)
            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, 155 , 123, 70, gripper_angle, isQueued = 1)[0] 
            dType.SetQueuedCmdStartExec(api)
            

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, 185, 108,10,0, isQueued = 1)[0] 
            dType.SetQueuedCmdStartExec(api)

            dType.dSleep(500)


        if color == "Verde":
            topic = "Verde"
            message = 1
            mqtt.enviar_mensaje_mqtt(broker, port, topic, message)
            Axis_x=datos[i][1]+185
            Axis_y=108-datos[i][2]# -3 del home en y, 30 de dimension y y esta en la posicion 1
            gripper_angle=datos[i][3]
            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, Axis_x , Axis_y, 10, -gripper_angle, isQueued = 1)[0]
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetQueuedCmdStopExec(api)
            dType.SetEndEffectorGripperEx(api, st,not st)
            dType.dSleep(500)

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, Axis_x , Axis_y, -4, -gripper_angle, isQueued = 1)[0]
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetEndEffectorGripperEx(api,st,not st)
            dType.SetQueuedCmdStopExec(api)
            dType.dSleep(500)

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, Axis_x , Axis_y, -20, -gripper_angle, isQueued = 1)[0]
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetEndEffectorGripperEx(api,st,st)
            dType.SetQueuedCmdStopExec(api)
            dType.dSleep(500)

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, Axis_x , Axis_y, 45, -gripper_angle, isQueued = 1)[0]
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetQueuedCmdStopExec(api)
            dType.SetEndEffectorGripperEx(api,st, st)
            dType.dSleep(500)

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, 133.76 , 198.40, 77, gripper_angle, isQueued = 1)[0] 
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetEndEffectorGripperEx(api,st,not st)
            dType.SetQueuedCmdStopExec(api)
            dType.dSleep(500)
            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, 224, 102,70,0, isQueued = 1)[0] 
            dType.SetQueuedCmdStartExec(api)


            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, 185, 108,10,0, isQueued = 1)[0] 
            dType.SetQueuedCmdStartExec(api)



        if color == "Azul":
            topic = "Azul"
            message = 1
            mqtt.enviar_mensaje_mqtt(broker, port, topic, message)
            Axis_x=datos[i][1]+185
            Axis_y=108-datos[i][2]# -3 del home en y, 30 de dimension y y esta en la posicion 1
            gripper_angle=datos[i][3]
            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, Axis_x , Axis_y, 10, -gripper_angle, isQueued = 1)[0]
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetQueuedCmdStopExec(api)
            dType.SetEndEffectorGripperEx(api, st,not st)
            dType.dSleep(500)

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, Axis_x , Axis_y, -4, -gripper_angle, isQueued = 1)[0]
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetEndEffectorGripperEx(api,st,not st)
            dType.SetQueuedCmdStopExec(api)
            dType.dSleep(500)

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, Axis_x , Axis_y, -20, -gripper_angle, isQueued = 1)[0]
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetEndEffectorGripperEx(api,st,st)
            dType.SetQueuedCmdStopExec(api)
            dType.dSleep(500)

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, Axis_x , Axis_y, 45, -gripper_angle, isQueued = 1)[0]
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetQueuedCmdStopExec(api)
            dType.SetEndEffectorGripperEx(api,st, st)
            dType.dSleep(500)

            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, 218.51 , 199, 77, gripper_angle, isQueued = 1)[0] 
            dType.SetQueuedCmdStartExec(api)
            while lastIndex1 > dType.GetQueuedCmdCurrentIndex(api)[0]:
                        dType.dSleep(500)
            dType.SetEndEffectorGripperEx(api,st,not st)
            dType.SetQueuedCmdStopExec(api)
            dType.dSleep(500)
            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, 224, 120,77,0 ,isQueued = 1)[0] 
            dType.SetQueuedCmdStartExec(api)


            lastIndex1 = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, 185, 108,10,0, isQueued = 1)[0] 
            dType.SetQueuedCmdStartExec(api)
            
    
    dType.SetEndEffectorGripperEx(api,not   st,  not st)

