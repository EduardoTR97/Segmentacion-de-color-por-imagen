print("Welcome MACI XI")
