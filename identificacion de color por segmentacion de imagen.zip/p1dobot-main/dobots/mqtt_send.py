import paho.mqtt.client as mqtt

# Configuración del broker MQTT
BROKER = "192.168.24.54"  # Dirección del broker
PORT = 1883               # Puerto del broker

def mensaje(topic, message):
    """
    Función para enviar un mensaje MQTT.
    
    Parámetros:
    - topic: Tema al que se enviará el mensaje.
    - message: Mensaje que se enviará.
    """
    # Callback que se ejecuta cuando se conecta al broker
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Conexión exitosa al broker")
        else:
            print(f"Error al conectar al broker, código de error: {rc}")

    # Crear cliente MQTT y configurar callbacks
    client = mqtt.Client()
    client.on_connect = on_connect

    try:
        # Conectar al broker
        client.connect(BROKER, PORT, keepalive=60)
        client.loop_start()  # Inicia el bucle de conexión
        
        # Publicar el mensaje
        client.publish(topic, message)
        print(f"Mensaje enviado: '{message}' al tema: '{topic}'")

    except Exception as e:
        print(f"Error al conectar o enviar mensaje: {e}")

    finally:
        # Detener el bucle y desconectar
        client.loop_stop()
        client.disconnect()

